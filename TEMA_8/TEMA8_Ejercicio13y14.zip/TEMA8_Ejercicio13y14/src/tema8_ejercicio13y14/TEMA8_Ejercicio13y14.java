/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tema8_ejercicio13y14;

import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class TEMA8_Ejercicio13y14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        System.out.println("=== EJERCICIO 13: CLASE ALUMNO ===\n");

        Alumno alumno1 = new Alumno();
        alumno1.setNombre("Maria Garcia");
        alumno1.setEdad(20);
        alumno1.setNotaMedia(7.5);

        Alumno alumno2 = new Alumno("Carlos Lopez", 22, 8.3);

        System.out.println("--- informacion de los alumnos ---");
        mostrarDatosAlumno(alumno1, "Alumno 1");
        mostrarDatosAlumno(alumno2, "Alumno 2");

        System.out.println("\n--- comparacion ---");
        if (alumno1.getNotaMedia() > alumno2.getNotaMedia()) {
            System.out.println(alumno1.getNombre() + " tiene mejor nota media");
        } else if (alumno2.getNotaMedia() > alumno1.getNotaMedia()) {
            System.out.println(alumno2.getNombre() + " tiene mejor nota media");
        } else {
            System.out.println("ambos alumnos tienen la misma nota media");
        }

        Scanner scanner = new Scanner(System.in);
        Alumno[] alumnos = new Alumno[5];
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero(scanner, "seleccione una opcion: ");
            System.out.println();

            switch (opcion) {
                case 1:
                    rellenarAlumno(scanner, alumnos);
                    break;
                case 2:
                    mostrarAlumnos(alumnos);
                    break;
                case 3:
                    mostrarAlumnosPorNota(scanner, alumnos);
                    break;
                case 4:
                    mostrarAlumnosSuspensos(alumnos);
                    break;
                case 5:
                    buscarAlumno(scanner, alumnos);
                    break;
                case 0:
                    System.out.println("hasta pronto");
                    break;
                default:
                    System.out.println("opcion no valida");
            }

            System.out.println();

        } while (opcion != 0);

        scanner.close();
    }

    // muestra el menu principal
    private static void mostrarMenu() {
        System.out.println("---------------------------------------");
        System.out.println("           MENU PRINCIPAL              ");
        System.out.println("---------------------------------------");
        System.out.println(" 1. rellenar un alumno                ");
        System.out.println(" 2. mostrar vector de alumnos         ");
        System.out.println(" 3. mostrar alumnos por encima de nota");
        System.out.println(" 4. mostrar alumnos suspensos         ");
        System.out.println(" 5. buscar alumno por nombre          ");
        System.out.println(" 0. salir                             ");
        System.out.println("---------------------------------------");
    }

    // rellena un alumno en una posicion del array
    private static void rellenarAlumno(Scanner scanner, Alumno[] alumnos) {
        int posicion;

        do {
            posicion = leerEntero(scanner, "ingrese la posicion (0-4): ");

            if (posicion < 0 || posicion >= alumnos.length) {
                System.out.println("posicion incorrecta");
            } else if (alumnos[posicion] != null) {
                System.out.println("esa posicion ya esta ocupada");
            } else {
                break;
            }
        } while (true);

        System.out.print("nombre del alumno: ");
        scanner.nextLine();
        String nombre = scanner.nextLine();

        int edad = leerEntero(scanner, "edad: ");
        double notaMedia = leerDouble(scanner, "nota media: ");

        alumnos[posicion] = new Alumno(nombre, edad, notaMedia);
        System.out.println("alumno guardado correctamente");
    }

    // muestra todos los alumnos
    private static void mostrarAlumnos(Alumno[] alumnos) {
        boolean hayAlumnos = false;

        for (int i = 0; i < alumnos.length; i++) {
            if (alumnos[i] != null) {
                hayAlumnos = true;
                System.out.println("\nposicion " + i);
                mostrarDatosAlumno(alumnos[i], null);
            }
        }

        if (!hayAlumnos) {
            System.out.println("no hay alumnos registrados");
        }
    }

    // muestra alumnos con nota superior a la indicada
    private static void mostrarAlumnosPorNota(Scanner scanner, Alumno[] alumnos) {
        double notaMinima = leerDouble(scanner, "ingrese la nota minima: ");
        boolean encontrado = false;

        for (Alumno alumno : alumnos) {
            if (alumno != null && alumno.getNotaMedia() > notaMinima) {
                encontrado = true;
                System.out.println(alumno.getNombre() + " - nota: " + alumno.getNotaMedia());
            }
        }

        if (!encontrado) {
            System.out.println("no hay alumnos con nota superior a " + notaMinima);
        }
    }

    // muestra alumnos suspensos
    private static void mostrarAlumnosSuspensos(Alumno[] alumnos) {
        int contador = 0;

        for (Alumno alumno : alumnos) {
            if (alumno != null && alumno.getNotaMedia() < 5) {
                contador++;
                System.out.println(alumno.getNombre() + " - nota: " + alumno.getNotaMedia());
            }
        }

        System.out.println("total de suspensos: " + contador);
    }

    // busca un alumno por nombre
    private static void buscarAlumno(Scanner scanner, Alumno[] alumnos) {
        System.out.print("nombre del alumno: ");
        scanner.nextLine();
        String nombre = scanner.nextLine();
        boolean encontrado = false;

        for (int i = 0; i < alumnos.length; i++) {
            if (alumnos[i] != null && alumnos[i].getNombre().equalsIgnoreCase(nombre)) {
                encontrado = true;
                System.out.println("alumno encontrado en la posicion " + i);
                mostrarDatosAlumno(alumnos[i], null);
                break;
            }
        }

        if (!encontrado) {
            System.out.println("el alumno no esta matriculado");
        }
    }

    // muestra los datos de un alumno
    private static void mostrarDatosAlumno(Alumno alumno, String titulo) {
        if (titulo != null) {
            System.out.println("\n" + titulo);
        }
        System.out.println("nombre: " + alumno.getNombre());
        System.out.println("edad: " + alumno.getEdad());
        System.out.println("nota media: " + alumno.getNotaMedia());
        System.out.println("estado: " + (alumno.getNotaMedia() >= 5 ? "APROBADO" : "SUSPENDIDO"));
    }

    // lee un numero entero usando nextInt
    private static int leerEntero(Scanner scanner, String mensaje) {
        int numero;

        System.out.print(mensaje);
        while (!scanner.hasNextInt()) {
            System.out.println("debe ingresar un numero entero");
            scanner.next();
            System.out.print(mensaje);
        }

        numero = scanner.nextInt();
        return numero;
    }

    // lee un numero decimal usando nextDouble
    private static double leerDouble(Scanner scanner, String mensaje) {
        double numero;

        System.out.print(mensaje);
        while (!scanner.hasNextDouble()) {
            System.out.println("debe ingresar un numero valido");
            scanner.next();
            System.out.print(mensaje);
        }

        numero = scanner.nextDouble();
        return numero;
    }
}